package com.bsfi.java.client.respository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.datastax.driver.core.Session;

/**
 * 
 * Respository to handle cassandra schema / keyspace
 *
 */

public class KeySpaceRepository {
	private Session session;
	
	private static final Logger LOG = LoggerFactory.getLogger(KeySpaceRepository.class);
	
	public KeySpaceRepository(Session session){
		this.session = session;
	}
	
	/**
	 * method to create the keyspace
	 * @param: schemaName is the name of the schema
	 * @param: replicationStrategy the replication strategy
	 * @param: numberofReplicas the number of replicas
	 */
	
	public void createKeyspace(String keyspaceName,String replicatoinStrategy, int numberOfReplicas) {
		StringBuilder sb = new StringBuilder("CREATE KEYSPACE IF NOT EXISTS ")
				.append(keyspaceName)
		  		.append(" WITH REPLICATION = { 'class' : '")
		  		.append(replicatoinStrategy)
		  		.append("', ")
		  		.append(" 'replication_factor' : ")
		  		.append(numberOfReplicas)
		  		.append(" };"); 


		final String query = sb.toString();
		LOG.info(query);
		
		session.execute(query);
	}
	
	/**
	 * method: delete the keyspace
	 * @param: schemaName to be deleted
	 */

	public void deleteKeyspace(String keyspaceName) {
		StringBuilder sb = new StringBuilder("DROP KEYSPACE ").append(keyspaceName);
		String query = sb.toString();
		
		session.execute(query);
	}
	
	
	public void useKeyspace(String keyspaceName) {
		StringBuilder sb = new StringBuilder("USE ").append(keyspaceName);
		String query = sb.toString();
		
		session.execute(query);
	}
}

