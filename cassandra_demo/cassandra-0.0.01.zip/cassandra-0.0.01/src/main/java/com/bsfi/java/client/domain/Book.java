package com.bsfi.java.client.domain;

import java.util.UUID;

public class Book {
	private UUID id;
	private String title;
	private String author;
	private String subject;
	private String publisher;
	
	Book() {
	}
	
	public Book(UUID id, String title, String author, String subject, String publisher){
		this.id = id;
		this.title = title;
		this.author = author;
		this.subject = subject;
		this.publisher = publisher;
	}
	
	public UUID getId() {
		return this.id;
	}
	
	public void setID(UUID id){ 
		this.id = id;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getAuthor() {
		return this.author;
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}
		
	public String getSubject() {
		return this.subject;
	}
	
	public void setSubject(String subject){
		this.subject = subject;
	}
	
	public String getPublisher() {
		return this.publisher;
	}
	
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
}
