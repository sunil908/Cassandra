package com.bsfi.java.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bsfi.java.client.domain.Book;
import com.bsfi.java.client.respository.BookRepository;
import com.bsfi.java.client.respository.KeySpaceRepository;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.utils.UUIDs;



public class CassandraClient {
	
	private static final Logger LOG = LoggerFactory.getLogger(CassandraClient.class);
	
	
	public static void main(String args[]) {
		CassandraConnector connector = new CassandraConnector();
		connector.connect("127.0.0.1", null);
		Session session = connector.getSession();
		
		KeySpaceRepository sr = new KeySpaceRepository(session);
		sr.createKeyspace("library", "SimpleStrategy", 1);
		sr.useKeyspace("library");
		
		BookRepository br = new BookRepository(session);
		br.createTable();
		// br.alterTablebooks("publisher2", "text");
		
		br.createTableBooksByTitle();
		
		Book bookrow = new Book(UUIDs.timeBased(),"Complete Java Reference", "John Cruff", "Programming","EDK Enterprises");
		bookrow.h
		br.insertBook(bookrow);
		br.insertBookByTitle(bookrow);
		
		LOG.info("Inserted book row into cassandra: " + bookrow.toString());
		
		Book bookrow2 = new Book(UUIDs.timeBased(),"Springboot for Dummies", "Adam Sand", "Programming","Mac grill Enterprises");
		br.insertBookBatch(bookrow2);
		
		LOG.info("Inserted book row into cassandra: " + bookrow2.toString());
		
		connector.close();
		
		LOG.info("End of the program...");
		
	}
	
	

}
