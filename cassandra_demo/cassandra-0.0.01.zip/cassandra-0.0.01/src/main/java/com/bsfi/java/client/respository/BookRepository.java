package com.bsfi.java.client.respository;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bsfi.java.client.domain.Book;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;

public class BookRepository {

		private static final String TABLE_NAME = "books";
		private static final String TABLE_NAME_BY_TITLE = TABLE_NAME + "ByTitle";
		
		private static final Logger LOG = LoggerFactory.getLogger(BookRepository.class);
		
		private Session session;
		
		public BookRepository(Session session) {
			this.session = session;
		}
		
		/**
		 * Creates the books table
		 */
		
		public void createTable(){
			StringBuilder sb = new StringBuilder("CREATE TABLE IF NOT EXISTS ").append(TABLE_NAME)
					.append("(")	
					.append("id uuid PRIMARY KEY,")
					.append("title text,")
					.append("author text,")
					.append("subject text);");
		final String query = sb.toString();
		
		LOG.info(query);
		
		session.execute(query);
		}
		/**
		 * creates the books table by title
		 */
		
		public void createTableBooksByTitle() {
			StringBuilder sb= new StringBuilder("CREATE TABLE IF NOT EXISTS ").append(TABLE_NAME_BY_TITLE)
					.append("(")
					.append("id uuid,")
					.append("title text PRIMARY KEY, ")
					.append("author text, ")
					.append("subject text);");
			final String query = sb.toString();
			LOG.info(query);
			session.execute(query);
		}
		/**
		 * Alters the table books and adds extra column with specified data type
		 * @param columnName
		 * @param columnType
		 */
		public void alterTablebooks(String columnName, String columnType) {
			StringBuilder sb = new StringBuilder("ALTER TABLE ")
					.append(TABLE_NAME)
					.append(" ADD ")
					.append(columnName).append(" ")
					.append(columnType)
					.append(";");
			final String query = sb.toString();
			session.execute(query);
		}
		
		/**
		 * 
		 * insert a row into books
		 */
		
		public void insertBook(Book book){
			StringBuilder sb = new StringBuilder("INSERT INTO ")
					.append(TABLE_NAME)
					.append("(id, title, author, subject) ")
					.append("VALUES ( ")
					.append(book.getId()).append(", '")
					.append(book.getTitle()).append("', '")
					.append(book.getAuthor()).append("', '")
					.append(book.getSubject()).append("');");
					
			final String query = sb.toString();
			LOG.info(query);
			session.execute(query);
		}
		
		/**
		 *  insert row into books by title
		 */
		
		public void insertBookByTitle(Book book){
			StringBuilder sb = new StringBuilder("INSERT INTO ")
								.append(TABLE_NAME_BY_TITLE)
								.append("(id, title )")
								.append("VALUES (")
								.append(book.getId())
								.append(", '")
								.append(book.getTitle())
								.append("');");
			final String query = sb.toString();
			session.execute(query);
		}
		
		public void insertBookBatch(Book book){
			StringBuilder sb = new StringBuilder("BEGIN BATCH ")
					.append("INSERT INTO ")
					.append(TABLE_NAME)
					.append("(id, title, author, subject) ")
					.append("VALUES (")
					.append(book.getId()).append(", '")
					.append(book.getTitle()).append("', '")
					.append(book.getAuthor()).append("', '")
					.append(book.getSubject()).append("');")
					.append("INSERT INTO ")
					.append(TABLE_NAME_BY_TITLE)
					.append("(id, title )")
					.append("VALUES (")
					.append(book.getId())
					.append(", '")
					.append(book.getTitle())
					.append("');")
					.append("APPLY BATCH");
			final String query = sb.toString();
			session.execute(query);
		}
		
		public Book selectByTitle(String title){
			StringBuilder sb = new StringBuilder("SELECT * FROM ")
					.append(TABLE_NAME_BY_TITLE)
					.append(" WHERE title= '")
					.append(title)
					.append("';");
			final String query = sb.toString();
			ResultSet rs= session.execute(query);
			
			List<Book> bookList = new ArrayList<Book>();
			
			for (Row r: rs) {
				Book s = new Book(r.getUUID("id"), r.getString("title"), null, null, null);
				bookList.add(s);
			}
			
			return (bookList.get(0));
			
		}
		
		/**
		 * Select all the books from table books
		 */
		
		public List<Book> selectAll(){
			StringBuilder sb = new StringBuilder("SELECT * FROM ").append(TABLE_NAME);
			
			final String query =sb.toString(); 
			ResultSet rs=session.execute(query);
			
			List<Book> bookAllList = new ArrayList<Book>();
			
			for(Row r:rs){
				Book bookRecord = new Book(r.getUUID("id"), r.getString("title"), r.getString("author"),
						r.getString("subject"), r.getString("publisher"));
				bookAllList.add(bookRecord);
			}
			
			return bookAllList;
		}
		
			/**
		     * Delete a book by title.
		    */
		    public void deletebookByTitle(String title) {
		        StringBuilder sb = new StringBuilder("DELETE FROM ").append(TABLE_NAME_BY_TITLE).append(" WHERE title = '").append(title).append("';");
	
		        final String query = sb.toString();
		        session.execute(query);
		    }
	
		    /**
		     * Delete table.
		     * 
		     * @param tableName the name of the table to delete.
		     */
		    public void deleteTable(String tableName) {
		        StringBuilder sb = new StringBuilder("DROP TABLE IF EXISTS ").append(tableName);
	
		        final String query = sb.toString();
		        session.execute(query);
		    }
		
}
