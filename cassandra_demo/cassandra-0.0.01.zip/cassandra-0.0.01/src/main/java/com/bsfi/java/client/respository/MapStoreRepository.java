package com.bsfi.java.client.respository;

public class MapStoreRepository {

}
